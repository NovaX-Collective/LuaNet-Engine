# Luanti Generative AI Policy

## Rationale

Generative AI tools, especially large language models (LLMs), have the
potential to boost the productivity of developers and contributors. However,
these tools have the unfortunate drawback that they greatly facilitate
low-quality contributions that are poorly understood by their authors, which in
turn wastes the time of Luanti's reviewers. As such, contributions to the
Luanti engine may only use generative AI tools as permitted by this policy.

## Prohibited uses of AI

The most important requirement when using AI tools is to understand and take
responsibility for your _entire_ contribution, regardless of whether AI tooling
was used, and to be respectful to others in your usage of AI tools.

That said, the following specific limitations are put in place:

- Generating substantial amounts of code with AI is strongly discouraged and
  may result in immediate closure of the PR. AI assistance may always be used
  for simple tasks, such as code completion, find-and-replace tasks, small
  bugfixes, or generating boilerplate code. On the other hand, "vibe-coding" or
  autonomous AI usage is completely unacceptable.

- Do not use AI-generated text when communicating with other humans, including
  when writing documentation. It is disrespectful to use a machine to generate
  text in response to another person, or to generate documentation and PR/issue
  descriptions meant for the benefit of humans. That said, using AI tools to
  assist with grammar or translations on human-written text is fine.

- AI may not be used to generate art, music, sounds, or any other media in the
  Luanti engine. Many people feel very strongly about how machines should be
  used to participate in the creative and artistic processes, and we respect
  those views highly, even though the engine itself has very little media.

Since the state of AI tooling is constantly changing, these restrictions may be
lifted or reinforced in the future.

## Permissible uses of AI

As a general rule, other usage of AI is permissible. Here are some notable
cases where generative AI is explicitly allowed:

- Exploring the Luanti codebase with "fuzzy" searches or understanding code
  architecture quickly with AI tooling.
- Using an LLM as a powerful search engine or knowledge base for coding
  purposes, as long as you truly understand your contribution.
- Having an AI tool review your code locally (not in the PR thread) or check
  for potential bugs in order to improve the quality of your contribution.
- Using an LLM to debug an issue or search for security vulnerabilities, but
  make sure to verify the analysis completely and communicate it yourself.

In any case, any significant AI usage used in a contribution must be disclosed
in the PR description.
